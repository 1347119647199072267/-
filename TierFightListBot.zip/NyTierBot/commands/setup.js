const { SlashCommandBuilder, PermissionFlagsBits, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { setGuildConfig, updateGuildMessageIds } = require('../utils/configManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup the queue system (Tester role required)')
        .addChannelOption(option =>
            option.setName('queue_channel')
                .setDescription('Channel for queue buttons')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('results_channel')
                .setDescription('Channel for evaluation results')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('control_channel')
                .setDescription('Channel for queue control panel')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('tickets_category')
                .setDescription('Category for test tickets')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true)),
    
    async execute(interaction) {
        const member = interaction.member;
        const hasTesterRole = member.roles.cache.some(role => role.name === 'Tester');
        
        if (!hasTesterRole) {
            return interaction.reply({
                content: '❌ You need the **Tester** role to use this command.',
                ephemeral: true
            });
        }

        const queueChannel = interaction.options.getChannel('queue_channel');
        const resultsChannel = interaction.options.getChannel('results_channel');
        const controlChannel = interaction.options.getChannel('control_channel');
        const ticketsCategory = interaction.options.getChannel('tickets_category');

        await interaction.deferReply({ ephemeral: true });

        try {
            const controlButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('open_queue')
                        .setLabel('Open Queue')
                        .setEmoji('🟢')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('close_queue')
                        .setLabel('Close Queue')
                        .setEmoji('🔴')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('start_test')
                        .setLabel('Start Test')
                        .setEmoji('⚙️')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('kick_player')
                        .setLabel('Kick Player')
                        .setEmoji('❌')
                        .setStyle(ButtonStyle.Secondary)
                );

            const controlEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle('🎮 Queue Control Panel')
                .setDescription('Use the buttons below to manage the queue system.')
                .setTimestamp();

            const controlMessage = await controlChannel.send({
                embeds: [controlEmbed],
                components: [controlButtons]
            });

            const queueButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('join_queue')
                        .setLabel('Join Queue')
                        .setEmoji('✅')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('leave_queue')
                        .setLabel('Leave Queue')
                        .setEmoji('❌')
                        .setStyle(ButtonStyle.Danger)
                );

            const queueEmbed = new EmbedBuilder()
                .setColor(0x95A5A6)
                .setTitle('⏸️ Queue Status')
                .setDescription('The queue is currently closed. Wait for a Tester to open it.')
                .setTimestamp();

            const queueMessage = await queueChannel.send({
                embeds: [queueEmbed],
                components: [queueButtons]
            });

            setGuildConfig(interaction.guildId, {
                queueChannel: queueChannel.id,
                resultsChannel: resultsChannel.id,
                controlChannel: controlChannel.id,
                ticketsCategory: ticketsCategory.id,
                queueMessageId: queueMessage.id,
                controlMessageId: controlMessage.id
            });

            await interaction.editReply({
                content: `✅ **Setup Complete!**\n\n` +
                         `📋 Queue Channel: ${queueChannel}\n` +
                         `📊 Results Channel: ${resultsChannel}\n` +
                         `🎛️ Control Channel: ${controlChannel}\n` +
                         `🎫 Tickets Category: ${ticketsCategory}`
            });

        } catch (error) {
            console.error('Setup error:', error);
            await interaction.editReply({
                content: '❌ An error occurred during setup. Please try again.'
            });
        }
    }
};
