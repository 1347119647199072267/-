const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getGuildConfig } = require('../utils/configManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('evaluate')
        .setDescription('Submit an evaluation result (Tester role required)')
        .addUserOption(option =>
            option.setName('username')
                .setDescription('Select Discord user')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('gamemode')
                .setDescription('Gamemode tested')
                .setRequired(true)
                .addChoices(
                    { name: 'Sword', value: 'Sword' },
                    { name: 'Axe', value: 'Axe' },
                    { name: 'Crystal', value: 'Crystal' },
                    { name: 'Mace', value: 'Mace' },
                    { name: 'SMP', value: 'SMP' },
                    { name: 'Diasmp', value: 'Diasmp' },
                    { name: 'Nethpot', value: 'Nethpot' },
                    { name: 'UHC', value: 'UHC' }
                ))
        .addStringOption(option =>
            option.setName('region')
                .setDescription('Player region')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('ign')
                .setDescription('In-game name')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('new_tier')
                .setDescription('New tier assigned')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('previous_tier')
                .setDescription('Previous tier (optional)')
                .setRequired(false)),
    
    async execute(interaction) {
        const member = interaction.member;
        const hasTesterRole = member.roles.cache.some(role => role.name === 'Tester');
        
        if (!hasTesterRole) {
            return interaction.reply({
                content: '❌ You need the **Tester** role to use this command.',
                ephemeral: true
            });
        }

        const config = getGuildConfig(interaction.guildId);
        if (!config || !config.resultsChannel) {
            return interaction.reply({
                content: '❌ Please run `/setup` first to configure the results channel.',
                ephemeral: true
            });
        }

        const user = interaction.options.getUser('username');
        const gamemode = interaction.options.getString('gamemode');
        const region = interaction.options.getString('region');
        const ign = interaction.options.getString('ign');
        const newTier = interaction.options.getString('new_tier');
        const previousTier = interaction.options.getString('previous_tier') || 'N/A';

        const ticketId = Math.floor(1000 + Math.random() * 9000);

        const resultEmbed = new EmbedBuilder()
            .setColor(0xF1C40F)
            .setTitle(`🏆 Result for ${user.username}`)
            .setDescription('✅ **Passed Evaluation**')
            .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
            .addFields(
                { name: 'Tester', value: `${interaction.user}`, inline: false },
                { name: 'Region', value: region, inline: true },
                { name: 'Gamemode', value: gamemode, inline: true },
                { name: 'IGN', value: ign, inline: true },
                { name: 'Previous Tier', value: previousTier, inline: true },
                { name: 'New Tier', value: newTier, inline: true }
            )
            .setTimestamp()
            .setFooter({ text: `Ticket ID: ${ticketId}` });

        try {
            const resultsChannel = await interaction.guild.channels.fetch(config.resultsChannel);
            await resultsChannel.send({ 
                content: `${user}`,
                embeds: [resultEmbed] 
            });

            await interaction.reply({
                content: `✅ Evaluation for **${user.username}** has been posted to ${resultsChannel}!`,
                ephemeral: true
            });
        } catch (error) {
            console.error('Evaluate error:', error);
            await interaction.reply({
                content: '❌ Failed to post evaluation. Make sure the results channel exists.',
                ephemeral: true
            });
        }
    }
};
