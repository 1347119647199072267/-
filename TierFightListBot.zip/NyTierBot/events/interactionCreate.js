const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, UserSelectMenuBuilder, ChannelType, PermissionFlagsBits, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig } = require('../utils/configManager');
const { getQueue, openQueue, closeQueue, addPlayer, removePlayer, GAMEMODES, QUEUE_LIMIT } = require('../utils/queueManager');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error('Command error:', error);
                const reply = {
                    content: '❌ There was an error executing this command.',
                    ephemeral: true
                };
                
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(reply);
                } else {
                    await interaction.reply(reply);
                }
            }
        }

        if (interaction.isButton()) {
            await handleButtonInteraction(interaction);
        }

        if (interaction.isStringSelectMenu()) {
            await handleGamemodeSelect(interaction);
        }

        if (interaction.isUserSelectMenu()) {
            await handleUserSelect(interaction);
        }
    }
};

async function handleButtonInteraction(interaction) {
    const { customId, member, guildId, guild } = interaction;
    const config = getGuildConfig(guildId);

    if (!config) {
        return interaction.reply({
            content: '❌ This server is not set up yet. Ask a Tester to run `/setup`.',
            ephemeral: true
        });
    }

    const hasTesterRole = member.roles.cache.some(role => role.name === 'Tester');

    switch (customId) {
        case 'open_queue':
            if (!hasTesterRole) {
                return interaction.reply({
                    content: '❌ Only Testers can open the queue.',
                    ephemeral: true
                });
            }

            const selectMenu = new ActionRowBuilder()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('select_gamemode')
                        .setPlaceholder('Select a gamemode')
                        .addOptions(
                            GAMEMODES.map(mode => ({
                                label: mode,
                                value: mode
                            }))
                        )
                );

            await interaction.reply({
                content: '🎮 **Select a gamemode to open the queue:**',
                components: [selectMenu],
                ephemeral: true
            });
            break;

        case 'close_queue':
            if (!hasTesterRole) {
                return interaction.reply({
                    content: '❌ Only Testers can close the queue.',
                    ephemeral: true
                });
            }

            const currentQueue = getQueue(guildId);
            const closingGamemode = currentQueue.gamemode || 'Unknown';
            closeQueue(guildId);
            await updateQueueMessage(interaction, config, 'closed', closingGamemode);
            await interaction.reply({
                content: '🔴 Queue has been closed.',
                ephemeral: true
            });
            break;

        case 'join_queue':
            const joinResult = addPlayer(guildId, member.id);
            
            if (!joinResult.success) {
                let message = '❌ ';
                if (joinResult.reason === 'already_in_queue') {
                    message += 'You are already in the queue!';
                } else if (joinResult.reason === 'queue_full') {
                    message += 'The queue is full! Please wait for a spot to open.';
                } else if (joinResult.reason === 'queue_closed') {
                    message += 'The queue is currently closed.';
                }
                
                return interaction.reply({
                    content: message,
                    ephemeral: true
                });
            }

            await updateQueueMessage(interaction, config, 'update');
            await interaction.reply({
                content: '✅ You have joined the queue!',
                ephemeral: true
            });
            break;

        case 'leave_queue':
            const leaveResult = removePlayer(guildId, member.id);
            
            if (!leaveResult.success) {
                return interaction.reply({
                    content: '❌ You are not in the queue.',
                    ephemeral: true
                });
            }

            await updateQueueMessage(interaction, config, 'update');
            await interaction.reply({
                content: '✅ You have left the queue.',
                ephemeral: true
            });
            break;

        case 'start_test':
            if (!hasTesterRole) {
                return interaction.reply({
                    content: '❌ Only Testers can start tests.',
                    ephemeral: true
                });
            }

            const queue = getQueue(guildId);
            if (queue.players.length === 0) {
                return interaction.reply({
                    content: '❌ There are no players in the queue.',
                    ephemeral: true
                });
            }

            const userSelect = new ActionRowBuilder()
                .addComponents(
                    new UserSelectMenuBuilder()
                        .setCustomId('select_player_test')
                        .setPlaceholder('Select a player to test')
                        .setMinValues(1)
                        .setMaxValues(1)
                );

            await interaction.reply({
                content: '👤 **Select a player to start their test:**',
                components: [userSelect],
                ephemeral: true
            });
            break;

        case 'kick_player':
            if (!hasTesterRole) {
                return interaction.reply({
                    content: '❌ Only Testers can kick players.',
                    ephemeral: true
                });
            }

            const kickQueue = getQueue(guildId);
            if (kickQueue.players.length === 0) {
                return interaction.reply({
                    content: '❌ There are no players in the queue to kick.',
                    ephemeral: true
                });
            }

            const kickUserSelect = new ActionRowBuilder()
                .addComponents(
                    new UserSelectMenuBuilder()
                        .setCustomId('select_player_kick')
                        .setPlaceholder('Select a player to kick')
                        .setMinValues(1)
                        .setMaxValues(1)
                );

            await interaction.reply({
                content: '👤 **Select a player to kick from the queue:**',
                components: [kickUserSelect],
                ephemeral: true
            });
            break;

        case 'close_ticket':
            if (interaction.channel.name.startsWith('ticket-')) {
                await interaction.reply({ content: '🗑️ Closing ticket...', ephemeral: true });
                setTimeout(async () => {
                    await interaction.channel.delete();
                }, 1000);
            }
            break;
    }
}

async function handleGamemodeSelect(interaction) {
    if (interaction.customId !== 'select_gamemode') return;

    const gamemode = interaction.values[0];
    const config = getGuildConfig(interaction.guildId);

    openQueue(interaction.guildId, gamemode, interaction.user.id);
    
    await updateQueueMessage(interaction, config, 'opened', gamemode);

    try {
        const queueChannel = await interaction.guild.channels.fetch(config.queueChannel);
        await queueChannel.send(`@everyone @here\n🎮 **The ${gamemode} queue is now open!**`);
    } catch (error) {
        console.error('Error sending queue notification:', error);
    }

    await interaction.update({
        content: `✅ Queue opened for **${gamemode}**!`,
        components: []
    });
}

async function handleUserSelect(interaction) {
    const selectedUserId = interaction.values[0];
    const config = getGuildConfig(interaction.guildId);

    if (interaction.customId === 'select_player_test') {
        try {
            const player = await interaction.guild.members.fetch(selectedUserId);
            
            const ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${player.user.username}`,
                type: ChannelType.GuildText,
                parent: config.ticketsCategory,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: interaction.user.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
                    },
                    {
                        id: selectedUserId,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
                    }
                ]
            });

            const closeButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('close_ticket')
                        .setLabel('Close Ticket')
                        .setEmoji('❌')
                        .setStyle(ButtonStyle.Danger)
                );

            const ticketEmbed = new EmbedBuilder()
                .setColor(0x3498DB)
                .setTitle('🎫 Test Ticket')
                .setDescription(`Welcome ${player}!\n\nTester ${interaction.user} will conduct your evaluation.\n\nGood luck!`)
                .setTimestamp();

            await ticketChannel.send({
                content: `${player} ${interaction.user}`,
                embeds: [ticketEmbed],
                components: [closeButton]
            });

            removePlayer(interaction.guildId, selectedUserId);
            await updateQueueMessage(interaction, config, 'update');

            await interaction.update({
                content: `✅ Test started with ${player} in ${ticketChannel}!`,
                components: []
            });
        } catch (error) {
            console.error('Error creating ticket:', error);
            await interaction.update({
                content: '❌ Failed to create ticket channel.',
                components: []
            });
        }
    }

    if (interaction.customId === 'select_player_kick') {
        try {
            const player = await interaction.guild.members.fetch(selectedUserId);
            removePlayer(interaction.guildId, selectedUserId);
            await updateQueueMessage(interaction, config, 'update');

            await interaction.update({
                content: `✅ ${player.user.tag} has been kicked from the queue.`,
                components: []
            });
        } catch (error) {
            console.error('Error kicking player:', error);
            await interaction.update({
                content: '❌ Failed to kick player.',
                components: []
            });
        }
    }
}

async function updateQueueMessage(interaction, config, action, gamemode = null) {
    try {
        const queueChannel = await interaction.guild.channels.fetch(config.queueChannel);
        const queueMessage = await queueChannel.messages.fetch(config.queueMessageId);
        
        const queue = getQueue(interaction.guildId);
        
        let embed;
        
        if (action === 'opened') {
            const tester = await interaction.guild.members.fetch(interaction.user.id);
            
            embed = new EmbedBuilder()
                .setColor(0x2ECC71)
                .setTitle('🟢 Queue Opened')
                .setDescription(`The queue for **${gamemode}** is now open and accepting new evaluations.\n\nClick the buttons below to join or leave the queue!`)
                .addFields(
                    { name: 'Opened by', value: `${tester}`, inline: false },
                    { name: 'Gamemode', value: gamemode, inline: true },
                    { name: 'Players in Queue', value: '0', inline: true },
                    { name: '📋 Queue List', value: '*No players yet*', inline: false }
                )
                .setTimestamp();
        } else if (action === 'closed') {
            const tester = await interaction.guild.members.fetch(interaction.user.id);
            const lastGamemode = gamemode || 'Unknown';
            
            embed = new EmbedBuilder()
                .setColor(0xE74C3C)
                .setTitle('🔴 Queue Closed')
                .setDescription(`The queue for **${lastGamemode}** has been closed and is no longer accepting new entries.`)
                .addFields(
                    { name: 'Closed by', value: `${tester}`, inline: false },
                    { name: 'Gamemode', value: lastGamemode, inline: true }
                )
                .setTimestamp();
        } else if (action === 'update') {
            if (!queue.isOpen) {
                embed = new EmbedBuilder()
                    .setColor(0x95A5A6)
                    .setTitle('⏸️ Queue Status')
                    .setDescription('The queue is currently closed. Wait for a Tester to open it.')
                    .setTimestamp();
            } else {
                const playerList = queue.players.length > 0 
                    ? (await Promise.all(queue.players.map(async (id, index) => {
                        try {
                            const member = await interaction.guild.members.fetch(id);
                            return `${index + 1}. ${member}`;
                        } catch {
                            return `${index + 1}. Unknown User`;
                        }
                    }))).join('\n')
                    : '*No players yet*';

                const tester = await interaction.guild.members.fetch(queue.openedBy);

                embed = new EmbedBuilder()
                    .setColor(0x2ECC71)
                    .setTitle('🟢 Queue Opened')
                    .setDescription(`The queue for **${queue.gamemode}** is now open and accepting new evaluations.\n\nClick the buttons below to join or leave the queue!`)
                    .addFields(
                        { name: 'Opened by', value: `${tester}`, inline: false },
                        { name: 'Gamemode', value: queue.gamemode, inline: true },
                        { name: 'Players in Queue', value: `${queue.players.length}`, inline: true },
                        { name: '📋 Queue List', value: playerList, inline: false }
                    )
                    .setTimestamp();
            }
        }

        const queueButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('join_queue')
                    .setLabel('Join Queue')
                    .setEmoji('✅')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('leave_queue')
                    .setLabel('Leave Queue')
                    .setEmoji('❌')
                    .setStyle(ButtonStyle.Danger)
            );

        await queueMessage.edit({
            embeds: [embed],
            components: [queueButtons]
        });
    } catch (error) {
        console.error('Error updating queue message:', error);
    }
}
