const queueData = new Map();

const QUEUE_LIMIT = 10;

const GAMEMODES = ['Sword', 'Axe', 'Crystal', 'Mace', 'SMP', 'Diasmp', 'Nethpot', 'UHC'];

function initQueue(guildId) {
    if (!queueData.has(guildId)) {
        queueData.set(guildId, {
            isOpen: false,
            gamemode: null,
            openedBy: null,
            players: []
        });
    }
}

function getQueue(guildId) {
    initQueue(guildId);
    return queueData.get(guildId);
}

function openQueue(guildId, gamemode, testerId) {
    initQueue(guildId);
    const queue = queueData.get(guildId);
    queue.isOpen = true;
    queue.gamemode = gamemode;
    queue.openedBy = testerId;
    queue.players = [];
}

function closeQueue(guildId) {
    initQueue(guildId);
    const queue = queueData.get(guildId);
    queue.isOpen = false;
    queue.gamemode = null;
    queue.openedBy = null;
    queue.players = [];
}

function addPlayer(guildId, userId) {
    initQueue(guildId);
    const queue = queueData.get(guildId);
    
    if (queue.players.includes(userId)) {
        return { success: false, reason: 'already_in_queue' };
    }
    
    if (queue.players.length >= QUEUE_LIMIT) {
        return { success: false, reason: 'queue_full' };
    }
    
    if (!queue.isOpen) {
        return { success: false, reason: 'queue_closed' };
    }
    
    queue.players.push(userId);
    return { success: true };
}

function removePlayer(guildId, userId) {
    initQueue(guildId);
    const queue = queueData.get(guildId);
    const index = queue.players.indexOf(userId);
    
    if (index === -1) {
        return { success: false, reason: 'not_in_queue' };
    }
    
    queue.players.splice(index, 1);
    return { success: true };
}

function getPlayers(guildId) {
    initQueue(guildId);
    return queueData.get(guildId).players;
}

function isQueueOpen(guildId) {
    initQueue(guildId);
    return queueData.get(guildId).isOpen;
}

module.exports = {
    GAMEMODES,
    QUEUE_LIMIT,
    getQueue,
    openQueue,
    closeQueue,
    addPlayer,
    removePlayer,
    getPlayers,
    isQueueOpen
};
