const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', 'config.json');

function loadConfig() {
    try {
        const data = fs.readFileSync(configPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return {};
    }
}

function saveConfig(config) {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
}

function getGuildConfig(guildId) {
    const config = loadConfig();
    return config[guildId] || null;
}

function setGuildConfig(guildId, channelData) {
    const config = loadConfig();
    config[guildId] = {
        queueChannel: channelData.queueChannel || '',
        resultsChannel: channelData.resultsChannel || '',
        controlChannel: channelData.controlChannel || '',
        ticketsCategory: channelData.ticketsCategory || '',
        queueMessageId: channelData.queueMessageId || '',
        controlMessageId: channelData.controlMessageId || ''
    };
    saveConfig(config);
}

function updateGuildMessageIds(guildId, messageIds) {
    const config = loadConfig();
    if (config[guildId]) {
        config[guildId].queueMessageId = messageIds.queueMessageId || config[guildId].queueMessageId;
        config[guildId].controlMessageId = messageIds.controlMessageId || config[guildId].controlMessageId;
        saveConfig(config);
    }
}

module.exports = {
    getGuildConfig,
    setGuildConfig,
    updateGuildMessageIds
};
